-- chapter-2
-- 1. Write queries that contain a WHERE clause to limit the output retrieved:

-- Retrieve payments made by customers with customer_id = 1001
SELECT *
FROM payment
WHERE customer_id = 1001;

-- Retrieve payments made with a mode other than 'Cash'
SELECT *
FROM payment
WHERE mode <> 'Cash';

-- 2. List the comparison operators and logical operators that are used in a WHERE clause:

-- Comparison Operators: =, <>, <, >, <=, >=
-- Logical Operators: AND, OR, NOT

-- Example:
SELECT *
FROM payment
WHERE amount > 1000 AND mode = 'Credit Card';

-- 3. Describe the rules of precedence for comparison and logical operators:

-- Comparison operators have higher precedence than logical operators. 
-- Operators within parentheses are evaluated first, and then logical operators are evaluated from left to right.

-- Example:
SELECT *
FROM payment
WHERE (amount > 1000 OR customer_id = 1002) AND mode = 'Credit Card';

-- 4. Use character string literals in the WHERE clause:

-- Retrieve payments made with a mode of 'Debit Card'
SELECT *
FROM payment
WHERE mode = 'Debit Card';

-- 5. Write queries that contain an ORDER BY clause to sort the output:

-- Sort payments by amount in ascending order
SELECT *
FROM payment
ORDER BY amount ASC;

-- Sort payments by payment_date in descending order
SELECT *
FROM payment
ORDER BY payment_date DESC;

-- 6. Sort output in descending and ascending order:

-- Sort payments by amount in descending order
SELECT *
FROM payment
ORDER BY amount DESC;

-- Sort payments by payment_date in ascending order
SELECT *
FROM payment
ORDER BY payment_date ASC;
