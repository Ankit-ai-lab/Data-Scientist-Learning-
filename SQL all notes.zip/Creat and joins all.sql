create database Ankit ;
use ankit;

create table Customers
	(CustomerID	int primary key not null,
	CustomerName varchar (200),
	ContactName varchar(200),
    Address	varchar (200),
    City varchar (200), 
	PostalCode int not null,
	Country varchar (200)) ;
    
    
    
    --  Create the table
CREATE TABLE orders (
    OrderID int,
    CustomerID int,
    EmployeeID int,
    OrderDate date,
    ShipperID int
);
-- Insert values into the payment table
INSERT INTO payment (customer_id, amount, mode, payment_date)
VALUES 
(16, 50, 'cash', '2022-09-25'),
(17, 51, 'cash', '2023-08-25');  



-- Create the customer table
CREATE TABLE customer (
    customer_id INT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    address_id INT
);
  
-- Insert values into the customer table
INSERT INTO customer (customer_id, first_name, last_name, email, address_id)
VALUES 
(1, 'Mary', 'Smith', 'mary.smith@mailid.com', 5),
(2, 'Patricia', 'Johnson', 'patricia.johnson@mailid.com', 6),
(3, 'Madan', 'Mohan', 'madan.mohan@mailid.com', 7),
(4, 'Barbara', 'Jones', 'barbara.jones@mailid.com', 8),
(5, 'Elizabeth', 'Brown', 'elizabeth.brown@mailid.com', 9),
(6, 'Jennifer', 'Davis', 'jennifer.davis@mailid.com', 10),
(7, 'Maria', 'Miller', 'maria.miller@mailid.com', 11),
(8, 'Susan', 'Wilson', 'susan.wilson@mailid.com', 12),
(9, 'R', 'Madhav', 'r.madhav@mailid.com', 13),
(10, 'Dorothy', 'Taylor', 'dorothy.taylor@mailid.com', 14),
(11, 'Lisa', 'Anderson', 'lisa.anderson@mailid.com', 15),
(12, 'Nancy', 'Thomas', 'nancy.thomas@mailid.com', 16),
(13, 'Karen', 'Jackson', 'karen.jackson@mailid.com', 17),
(14, 'Betty', 'White', 'betty.white@mailid.com', 18),
(15, 'Helen', 'Harris', 'helen.harris@mailid.com', 19);




SELECT c.first_name, p.amount, p.mode
FROM ankit.customer as c
left join payment as p
on c.customer_id = p.customer_id;


SELECT *
FROM ankit.payment as p
 join customer as c
on c.customer_id = p.customer_id;
-- use ankit;
-- full join using union
SELECT *
FROM customer
LEFT JOIN payment ON customer.customer_id = payment.customer_id
UNION
SELECT *
FROM customer
RIGHT JOIN payment 
ON customer.customer_id = payment.customer_id;






 
select * 
from ankit.customer as c
right join ankit.payment as p
on c.customer_id= p.customer_id

UNION 

select * 
from ankit.customer as c
left join ankit.payment as p
on c.customer_id= p.customer_id;  -- i perform hear full joins

-- opperators
select * from employee




select * 
from ankit.customer as c
inner join ankit.payment as p
on c.customer_id = p.customer_id;
  
SELECT * FROM ankit.customer;
SELECT * FROM ankit.payment;

use ankit;

select * 
from customer as c
right join payment as p
on c.customer_id = p.cus  customer _id; 




