-- chapter 6
-- 1. Display Data From Multiple Tables Using Joins:

-- Task 1: Display Data From Multiple Tables Using Joins
-- Problem Statement: Retrieve information from the "payment" table along with corresponding customer details such as name and email.
SELECT *
FROM payment
JOIN customer ON payment.customer_id = customer.customer_id;


-- Task 2: Create a Simple and Complex View
-- Problem Statement: Create two views - one that includes payment ID, customer ID, and amount, and another that combines payment details with customer names.
CREATE VIEW simple_payment_view AS
SELECT customer_id, amount, mode, payment_date
FROM payment;



CREATE VIEW complex_payment_view AS
SELECT p.customer_id, p.amount, p.mode, p.payment_date, c.first_name, c.last_name
FROM payment p
JOIN customer c ON p.customer_id = c.customer_id;



-- Task 3: Retrieve Data From Views
-- Problem Statement: Retrieve data from both the simple and complex views.
SELECT * FROM simple_payment_view;
SELECT * FROM complex_payment_view;


-- Task 4: Create, Maintain, and Use Sequences
-- Problem Statement: Create a sequence for generating unique payment IDs, then use it to insert a new payment record.
ALTER TABLE payment
ADD COLUMN payment_id INT AUTO_INCREMENT PRIMARY KEY;

INSERT INTO payment (customer_id, amount, mode, payment_date)
VALUES (1001, 500, 'Credit Card', '2023-10-07');


-- Task 5: Create and Maintain Indexes
-- Problem Statement: Create an index on the customer ID column in the "payment" table for faster retrieval.
CREATE INDEX idx_customer_id ON payment (customer_id);


-- Task 6: Create Private and Public Synonyms
-- Problem Statement: Create a private synonym for the "payment" table, and a public synonym accessible to all users.
CREATE VIEW my_payment AS
SELECT * FROM payment;



