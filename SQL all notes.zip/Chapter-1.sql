-- chapter 3
-- 1. Retrieving Data from One or More Tables:
SELECT *
FROM payment;

-- 2. Selecting Specific Columns or All Columns:
SELECT customer_id, amount, payment_date
FROM payment;

-- 3. Filtering Data Using WHERE Clauses:
SELECT *
FROM payment
WHERE mode = 'Credit Card';

-- 4. Sorting Data Using ORDER BY:
SELECT customer_id, amount
FROM payment
ORDER BY amount DESC;

-- 5. Performing Calculations and Using Functions:
SELECT customer_id, amount * 1.1 AS increased_amount
FROM payment;



-- 7. Grouping and Aggregating Data Using GROUP BY:
SELECT customer_id, COUNT(*) AS num_payments, SUM(amount) AS total_amount
FROM payment
GROUP BY customer_id;

-- 8. Subqueries to Perform Complex Operations:
SELECT customer_id, amount
FROM payment
WHERE amount > (SELECT AVG(amount) FROM payment);





