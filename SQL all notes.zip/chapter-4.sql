-- chapter 4
-- 1. Implicit and Explicit Data Type Conversion
-- Implicit Conversion Example
SELECT customer_id, amount * 1.1 AS increased_amount
FROM payment;
use ankit;
-- Explicit Conversion Example (TO_NUMBER function)
SELECT customer_id, CAST(amount AS DECIMAL(10,2)) + 100 AS increased_amount
FROM payment
LIMIT 2000;


-- 2. Using TO_CHAR, TO_NUMBER, and TO_DATE Functions
-- TO_CHAR: Convert payment_date to 'DD-MON-YYYY' format
SELECT DATE_FORMAT(payment_date, '%d-%b-%Y') AS formatted_date
FROM payment
LIMIT 2000;


-- TO_NUMBER: Convert amount to a number (explicit conversion, not necessary here)
SELECT customer_id, CAST(amount AS DECIMAL(10,2)) AS numeric_amount
FROM payment
LIMIT 2000;


-- TO_DATE: Convert a string to a date
SELECT STR_TO_DATE('2023-10-07', '%Y-%m-%d') AS converted_date
FROM payment
LIMIT 2000;

-- FROM dual; -- 'dual' is a dummy table used for selecting literal values


-- 3. Nesting Multiple Functions
-- Convert and format payment_date to 'YYYY-MM-DD'
SELECT DATE_FORMAT(payment_date, '%Y-%m-%d') AS formatted_date
FROM payment
LIMIT 2000;



-- 4. Applying NVL, NULLIF, and COALESCE Functions
-- NVL: Replace NULL values with a specified value
SELECT customer_id, COALESCE(mode, 'No Mode Specified') AS updated_mode
FROM payment
LIMIT 2000;

-- NULLIF: Return NULL if two expressions are equal
SELECT NULLIF(amount, 0) AS non_zero_amount
FROM payment;

-- COALESCE: Return the first non-NULL value from a list of expressions
SELECT COALESCE(mode, 'No Mode Specified') AS first_non_null_mode
FROM payment;


-- 5. Conditional IF THEN ELSE Logic
SELECT customer_id, 
       amount,
       CASE 
           WHEN amount > 1000 THEN 'High Amount'
           WHEN amount > 500 THEN 'Medium Amount'
           ELSE 'Low Amount'
       END AS amount_category
FROM payment;
