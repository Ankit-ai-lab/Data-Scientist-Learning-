-- CHAPTER 3
/* Learn to Restrict and Sort Data
Write queries that contain a WHERE clause to limit the output retrieved List 
the comparison operators and logical operators that are used in a WHERE
clause
Describe the rules of precedence for comparison and logical operators Use
character stringliterals in the WHERE clause
Write queries that contain an ORDER BY clause to sort the output of a 
SELECTstatement
Sort output in descendingand ascendingorder*/

USE ANKIT;
SELECT * FROM EMPLOYEE;
--  Restrict Data using WHERE Clause
-- Retrieve employees with age greater than 30
SELECT * FROM employee WHERE age > 30;

ALTER TABLE EMPLOYEE
ADD COLUMN AGE INT;

UPDATE EMPLOYEE
SET AGE = 32	
WHERE EMP_ID = 1;

UPDATE EMPLOYEE
SET AGE = 38
WHERE EMP_ID = 4;


-- Retrieve employees with a salary of at least 55000
SELECT * FROM employee WHERE salary >= 55000;


/*1.2. List the comparison operators and logical operators that are used in a WHERE clause:
Comparison Operators:

= (Equal to)
<> or != (Not equal to)
< (Less than)
> (Greater than)
<= (Less than or equal to)
>= (Greater than or equal to)
*/

/*Logical Operators:

AND (both conditions must be true)
OR (at least one condition must be true)
NOT (negates a condition)*/


-- 2: Describe the Rules of Precedence for Operators
SELECT * FROM employee WHERE (age > 30 OR salary > 55000) AND first_name = 'John';


-- 3: Use Character String Literals in the WHERE Clause
SELECT * FROM employee WHERE first_name = 'Jane';

-- 4: Write Queries with ORDER BY Clause for Sorting

-- Sort employees by age in ascending order
SELECT * FROM employee ORDER BY age ASC;

-- Sort Output in Descending and Ascending Order:Sort Output in Descending and Ascending Order:\

-- Sort employees by salary in descending order
SELECT * FROM employee ORDER BY salary DESC;

-- Sort employees by first name in ascending order
SELECT * FROM employee ORDER BY first_name;






