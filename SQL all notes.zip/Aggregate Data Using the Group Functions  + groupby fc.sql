-- GROUP BY
-- Aggregate Data Using the Group Functions
SELECT first_name, last_name, COUNT(*) as employee_count, AVG(salary) as avg_salary
FROM employee
GROUP BY first_name, last_name;
 

--  Step 1: Aggregate Data Using Group Functions
-- Example 1: Calculate the Total Salary for Each EMP_ID
SELECT EMP_ID, SUM(salary) AS total_salary
FROM employee
GROUP BY EMP_ID;

--


select * from employee;

-- 1: Calculate the Total Number of Customers
SELECT COUNT(*) AS total_customers
FROM customer;

-- 2: Find the Average Address ID
SELECT sum(amount) AS avg_payment_amount
FROM payment;

-- 4: Find Customers with Last Names Starting with 'S'
SELECT *
FROM customer
WHERE last_name LIKE 'S%';


 -- having clause? pending


