-- new
use ankit;
CREATE TABLE employee (
    emp_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    salary DECIMAL(10, 2),
    hire_date DATE
);

-- Inserting Sample Values
INSERT INTO employee (emp_id, first_name, last_name, salary, hire_date)
VALUES 
    (1, 'John', 'Doe', 50000, '2020-01-15'),
    (2, 'Jane', 'Smith', 60000, '2019-05-20'),
    (3, 'Jim', 'Brown', 45000, '2021-08-10'); 



-- . Single-Row Functions:

-- Example: Concatenating first_name and last_name
SELECT hire_date || ' ' || salary full_name
FROM employee;

select * from employee;
--  Number Functions (ROUND, TRUNC, MOD):
-- Example: Rounding salary to the nearest hundred
SELECT emp_id, ROUND(salary, -2) AS rounded_salary
FROM employee;

-- Example: Calculating years of service for each employee
SELECT emp_id, 
EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM hire_date) AS years_of_service
FROM employee;

select emp_id,
EXTRACT (year from current_date)  extract (year from hire_date) as years_of_service
from employee;

-- 3. Manipulating Strings with Character Functions:
-- Character functions can be used to perform operations on string data. Examples include UPPER, LOWER, LENGTH, SUBSTRING, etc.
/*-- 1.1. UPPER() and LOWER() Functions:
UPPER(): Converts a string to uppercase.
LOWER(): Converts a string to lowercase./*
    

-- 2. LENGTH() Function:
-- Returns the length of a string (number of characters).
SELECT first_name, LENGTH(first_name) AS name_length
FROM employee;

-- 3. SUBSTRING() or SUBSTR() Function:
-- Extracts a substring from a string
SELECT 
    first_name,
    SUBSTRING(first_name, 1, 3) AS first_three_chars
FROM employee;


-- 4. CONCAT() Function:
-- Concatenates two or more strings.\
SELECT 
    first_name,
    last_name,
    CONCAT(first_name, ' ', last_name) AS full_name
FROM employee;


-- 5. INSTR() Function:
-- Finds the position of a substring within a string.
SELECT 
    first_name,
    INSTR(first_name, 'a') AS position_of_a
FROM employee;

   

-- 6. REPLACE() Function:
-- Replaces a substring with another substring.
SELECT 
first_name,
REPLACE(first_name, 'i', 'F') AS modified_name
FROM employee;

SELECT 
LAST_NAME,
REPLACE(LAST_NAME, 'd', 'p') AS MODIFIED_NAME
FROM EMPLOYEE; 

SELECT 
  FIRST_NAME,
  REPLACE(UPPER(LAST_NAME), 'J', 'p') AS MODIFIED_NAME
FROM EMPLOYEE;


--- UPDATE 
UPDATE EMPLOYEE
SET FIRST_NAME = 'Ankit'
WHERE FIRST_NAME = 'jim'
LIMIT 1;
 -- select * from employee;




-- -- Example: Finding the length of the first_name

SELECT upper(first_name) AS name_length
FROM employee;

-- 4. Manipulating Numbers with ROUND, and MOD Functions
select emp_id, mod(	salary, -2) rounded_salary
from employee;

-- 5Performing Arithmetic with Date Data:
-- Example: Calculating years of service for each employee
SELECT emp_id, 
       EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM hire_date) AS years_of_service
FROM employee;   -- 



-- 6. Manipulating Dates with DATE Functions:
SELECT emp_id, hire_date, LAST_DAY(hire_date) AS last_day_of_month
FROM employee;


-- Manipulating Dates:
-- Example: Calculating years of service for each employee
SELECT emp_id, 
       hire_date, 
       EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM hire_date) AS years_of_service
FROM employee;
SELECT * FROM EMPLOYEE;
-- Date Functions:
-- Example: Finding the last day of the month when an employee was hired
SELECT emp_id, hire_date, LAST_DAY(hire_date) AS last_day_of_month
FROM employee;

-- Single-Row Functions operate on each individual row of the result set and return one result per row.
-- Multiple-Row Functions (not covered here) operate on multiple rows and return one result.
--  Character functions can manipulate string data, such as concatenation or extracting substrings.
-- Number functions can perform operations on numeric data, like rounding, truncating, or finding the remainder.
-- Date functions provide various operations for working with date data, like extracting components or finding the last day of a month.

SELECT * FROM ankit.employee;

-- Invoke Conversion Functions and Conditional Expressions

SELECT emp_id, DATE_FORMAT(hire_date, '%d-%b-%Y') AS hire_date_str
FROM employee
LIMIT 2000;



-- This converts the hire_date to a string in the format 'DD-MON-YYYY'

-- TO_NUMBER:
SELECT emp_id, CAST(salary AS DECIMAL(10, 2)) * 1.1 AS increased_salary
FROM employee
LIMIT 2000;

SELECT * FROM employee;

-- to date  
SELECT emp_id, STR_TO_DATE('01-JAN-2023', '%d-%b-%Y') AS new_year_date
FROM employee
LIMIT 2000;



--
-- 3. Nesting Functions:
SELECT emp_id, 
       DATE_FORMAT(DATE_ADD(CAST('2023-01-01' AS DATE), INTERVAL 10 DAY), '%d-%b-%Y') AS new_date
FROM employee;


/* CAST('2023-01-01' AS DATE):

This function is used to explicitly convert the string '2023-01-01' to a date data type.
DATE_ADD(...):

This is a MySQL function that adds a specified interval to a date. In this case, it's adding 10 days to the date.
DATE_FORMAT(..., '%d-%b-%Y'):

This function is used to format the date. It takes two arguments: the date and the format string.
%d represents the day, %b represents the abbreviated month name, and %Y represents the year in four digits./*


### condition in SQL

-- Conditional IF THEN ELSE Logic -- we are cheking hear when 
SELECT emp_id, 
       CASE 
           WHEN salary > 50000 THEN 'High'
           ELSE 'Low'
       END AS salary_category
FROM employee;

select emp_id
		case 
			when salary > 50000 Then 'High'
			Else 'low'
		end as salary_categor
from employee;


SELECT emp_id,
       CASE 
           WHEN salary > 50000 THEN 'High'
           ELSE 'Low'
       END AS salary_category
FROM employee;
-- SELECT * FROM ankit.employee;
use ankit;
/*-- set opperator
--SET Operators:
SET operators in SQL are used to perform operations on the result sets of multiple SELECT queries. There are three main SET operators:*/
/*
UNION: This combines the result sets of two or more SELECT queries into a single result set, removing duplicates.

INTERSECT: This returns the common rows between the result sets of two or more SELECT queries, excluding duplicates.

MINUS (or EXCEPT in some databases): This returns the rows that are unique to the first result set and not present in the second result set, also excluding duplicates.*/

--  you have two tables, employ and simple, and you want to combine the results:

select * from customer  # Combining Multiple Queries:
union
select * from employee;

select * from payment;

--
SELECT * FROM employee
ORDER BY salary asc;  ## asc and desc  

/*  INTERSECT Operator:
The INTERSECT operator returns only the rows that are common to the result sets of two or more SELECT queries. It excludes duplicate rows.*/



