-- chapter 20
-- Create a sample table
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    quantity INT,
    price DECIMAL(10, 2)
);

-- Insert some sample data
INSERT INTO orders (order_id, product_name, quantity, price) VALUES
    (1, 'Product A', 10, 100.00),
    (2, 'Product B', 5, 50.00),
    (3, 'Product C', 8, 80.00),
    (4, 'Product A', 12, 120.00),
    (5, 'Product D', 7, 70.00);

-- Retrieve data using subqueries

-- Multiple-Column Subqueries
SELECT product_name, quantity
FROM orders
WHERE (quantity, price) IN (SELECT MAX(quantity), MAX(price) FROM orders);

-- Scalar Subquery Expressions
SELECT product_name,
       (SELECT MAX(quantity) FROM orders) AS max_quantity
FROM orders;

-- Correlated Subqueries
SELECT order_id, product_name, quantity
FROM orders o1
WHERE quantity > (SELECT AVG(quantity) FROM orders o2 WHERE o2.product_name = o1.product_name);

-- Update and Delete Rows Using Correlated Subqueries
UPDATE orders o
JOIN (
    SELECT product_name, AVG(price) AS avg_price
    FROM orders
    GROUP BY product_name
) subquery ON o.product_name = subquery.product_name
SET o.price = subquery.avg_price
WHERE o.product_name = 'Product A';


DELETE FROM orders
WHERE quantity < (
    SELECT avg_quantity
    FROM (
        SELECT AVG(quantity) as avg_quantity
        FROM orders
    ) subquery
);


-- The EXISTS and NOT EXISTS operators
SELECT DISTINCT product_name
FROM orders o1
WHERE EXISTS (
    SELECT 1
    FROM orders o2
    WHERE o1.product_name = o2.product_name AND quantity > 10
);

SELECT DISTINCT product_name
FROM orders o1
WHERE NOT EXISTS (
    SELECT 1
    FROM orders o2
    WHERE o1.product_name = o2.product_name AND quantity > 10
);

-- Invoke the WITH clause
WITH high_quantity_orders AS (
    SELECT order_id, product_name, quantity
    FROM orders
    WHERE quantity > 10
)
SELECT * FROM high_quantity_orders;

-- The Recursive WITH clause
WITH recursive cte (n) AS (
    SELECT 1
    UNION ALL
    SELECT n + 1 FROM cte WHERE n < 10
)
SELECT n FROM cte;
