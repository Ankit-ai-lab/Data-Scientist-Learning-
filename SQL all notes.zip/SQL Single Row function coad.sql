
-- . Single-Row Functions:

-- Example: Concatenating first_name and last_name
SELECT hire_date || ' ' || salary full_name
FROM employee;

select * from employee;
--  Number Functions (ROUND, TRUNC, MOD):
-- Example: Rounding salary to the nearest hundred
SELECT emp_id, ROUND(salary, -2) AS rounded_salary
FROM employee;

-- Example: Calculating years of service for each employee
SELECT emp_id, 
       EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM hire_date) AS years_of_service
FROM employee;

-- 3. Manipulating Strings with Character Functions:
-- Character functions can be used to perform operations on string data. Examples include UPPER, LOWER, LENGTH, SUBSTRING, etc.
/*-- 1.1. UPPER() and LOWER() Functions:
UPPER(): Converts a string to uppercase.
LOWER(): Converts a string to lowercase./*
SELECT 
UPPER (FIRST_NAME)AS UPPER_NAME,
LOWER (LAST_NAME) AS LOWER_NAME
FROM EMPLOYEE;

-- 2. LENGTH() Function:
-- Returns the length of a string (number of characters).
SELECT first_name, LENGTH(first_name) AS name_length
FROM employee;

-- 3. SUBSTRING() or SUBSTR() Function:
-- Extracts a substring from a string
SELECT 
    first_name,
    SUBSTRING(first_name, 1, 3) AS first_three_chars
FROM employee;


-- 4. CONCAT() Function:
-- Concatenates two or more strings.\
SELECT 
    first_name,
    last_name,
    CONCAT(first_name, ' ', last_name) AS full_name
FROM employee;


-- 5. INSTR() Function:
-- Finds the position of a substring within a string.
SELECT 
    first_name,
    INSTR(first_name, 'a') AS position_of_a
FROM employee;



-- 6. REPLACE() Function:
-- Replaces a substring with another substring.
SELECT 
first_name,
REPLACE(first_name, 'i', 'F') AS modified_name
FROM employee;

SELECT 
LAST_NAME,
REPLACE(LAST_NAME, 'd', 'p') AS MODIFIED_NAME
FROM EMPLOYEE; 

SELECT 
  FIRST_NAME,
  REPLACE(UPPER(LAST_NAME), 'J', 'p') AS MODIFIED_NAME
FROM EMPLOYEE;


--- UPDATE 
UPDATE EMPLOYEE
SET FIRST_NAME = 'Ankit'
WHERE FIRST_NAME = 'jim'
LIMIT 1;
 -- select * from employee;




-- -- Example: Finding the length of the first_name

SELECT upper(first_name) AS name_length
FROM employee;

-- 4. Manipulating Numbers with ROUND, and MOD Functions
select emp_id, mod(	salary, -2) rounded_salary
from employee;

-- 5Performing Arithmetic with Date Data:
-- Example: Calculating years of service for each employee
SELECT emp_id, 
       EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM hire_date) AS years_of_service
FROM employee;   -- 



-- 6. Manipulating Dates with DATE Functions:
SELECT emp_id, hire_date, LAST_DAY(hire_date) AS last_day_of_month
FROM employee;


-- Manipulating Dates:
-- Example: Calculating years of service for each employee
SELECT emp_id, 
       hire_date, 
       EXTRACT(YEAR FROM CURRENT_DATE) - EXTRACT(YEAR FROM hire_date) AS years_of_service
FROM employee;
SELECT * FROM EMPLOYEE;
-- Date Functions:
-- Example: Finding the last day of the month when an employee was hired
SELECT emp_id, hire_date, LAST_DAY(hire_date) AS last_day_of_month
FROM employee;

-- Single-Row Functions operate on each individual row of the result set and return one result per row.
-- Multiple-Row Functions (not covered here) operate on multiple rows and return one result.
--  Character functions can manipulate string data, such as concatenation or extracting substrings.
-- Number functions can perform operations on numeric data, like rounding, truncating, or finding the remainder.
-- Date functions provide various operations for working with date data, like extracting components or finding the last day of a month.