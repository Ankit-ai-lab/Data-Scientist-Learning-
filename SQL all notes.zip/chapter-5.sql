-- 5chapter
-- 1. Use Aggregate Functions in SELECT Statements:
-- Calculate the total amount of all payments
SELECT SUM(amount) AS total_amount
FROM payment;

-- Find the average amount of payments
SELECT AVG(amount) AS average_amount
FROM payment;

-- Determine the highest amount of a payment
SELECT MAX(amount) AS highest_amount
FROM payment;

-- Identify the lowest amount of a payment
SELECT MIN(amount) AS lowest_amount
FROM payment;

-- Count the total number of payments
SELECT COUNT(*) AS total_payments
FROM payment;


-- 2. Divide the Data into Groups using GROUP BY:
-- Calculate the total amount of payments for each mode
SELECT mode, SUM(amount) AS total_amount
FROM payment
GROUP BY mode;

-- Find the average amount of payments for each customer
SELECT customer_id, AVG(amount) AS average_amount
FROM payment
GROUP BY customer_id;

-- 3. Exclude Groups of Data using the HAVING Clause:
-- Find modes with a total amount greater than 2000
SELECT mode, SUM(amount) AS total_amount
FROM payment
GROUP BY mode
HAVING total_amount > 2000;

-- Find customers with an average payment amount over 500
SELECT customer_id, AVG(amount) AS average_amount
FROM payment
GROUP BY customer_id
HAVING average_amount > 500;

