use ankit;
-- SELECT * FROM ankit.payment;
-- all clause perform 
-- FROM Clause - Specify the table you're querying from:
SELECT *
FROM payment;

-- WHERE Clause - Filter the rows based on a condition (if needed):
SELECT *
FROM payment
WHERE mode = 'Credit Card';


-- GROUP BY Clause - Group the rows based on a column (if needed):
SELECT mode, SUM(amount) AS total_amount
FROM payment
group by mode;




-- HAVING Clause - Filter groups based on a condition (if needed):
SELECT mode, SUM(amount) AS total_amount
FROM payment
GROUP BY mode
having   total_amount > 100;


-- ORDER BY Clause - Sort the result set (if needed):
SELECT amount, mode
FROM payment
ORDER BY payment_date DESC;


-- LIMIT Clause - Limit the number of rows in the result set (if needed):
SELECT amount, mode
FROM payment
LIMIT 5;


-- Get the total amount for each payment mode where the total amount is greater than 100, ordered by payment date:
SELECT mode, SUM(amount) AS total_amount
FROM payment
GROUP BY mode
HAVING total_amount > 100
ORDER BY MAX(payment_date)
LIMIT 0, 2000;


--  Get the top 3 highest payment amounts made using Credit Card:
SELECT *
FROM payment
WHERE mode = 'Credit Card'
ORDER BY amount DESC
LIMIT 3;


use ankit;
-- SELECT *
SELECT mode, SUM(amount) AS total_amount
FROM payment
WHERE mode = 'Credit Card'
GROUP BY mode
HAVING SUM(amount) > 100



