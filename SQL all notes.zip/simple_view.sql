-- Create a simple view
CREATE VIEW simple_payment_view AS
SELECT customer_id, amount
FROM payment
WHERE mode = 'Credit Card';

-- Create a complex view
CREATE VIEW complex_payment_view AS
SELECT p.customer_id, p.amount, c.first_name, c.last_name
FROM payment p
JOIN customer c ON p.customer_id = c.customer_id
WHERE p.amount > 1000;

-- Retrieve data from a view
SELECT * FROM simple_payment_view;
SELECT * FROM complex_payment_view;
