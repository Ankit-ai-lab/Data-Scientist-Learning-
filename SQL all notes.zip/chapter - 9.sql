--  chapter - 9
-- Retrieve all payments made by customers
SELECT *
FROM payment;

-- Retrieve the total amount paid by each customer
SELECT customer_id, SUM(amount) AS total_amount_paid
FROM payment
GROUP BY customer_id;

-- Find customers who have made payments over $1000
SELECT c.customer_id, c.first_name, c.last_name
FROM customer c
JOIN payment p ON c.customer_id = p.customer_id
WHERE p.amount > 1000;

-- List the customers who haven't made any payments
SELECT c.customer_id, c.first_name, c.last_name
FROM customer c
LEFT JOIN payment p ON c.customer_id = p.customer_id
WHERE p.customer_id IS NULL;

-- Retrieve the highest payment amount
SELECT MAX(amount) AS highest_payment_amount
FROM payment;

-- Find the customer with the highest payment amount
SELECT c.first_name, c.last_name
FROM customer c
JOIN payment p ON c.customer_id = p.customer_id
WHERE p.amount = (SELECT MAX(amount) FROM payment);

-- Get the total number of payments
SELECT COUNT(*) AS total_payments
FROM payment;



-- Retrieve payments sorted by amount in descending order
SELECT *
FROM payment
ORDER BY amount DESC;

-- Retrieve the distinct modes of payment
SELECT DISTINCT mode
FROM payment;
