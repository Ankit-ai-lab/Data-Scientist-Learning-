-- Use Subqueries to Solve Queries
/*Describe the types of problem that sub-queries can solve 
Define sub-queries
List the types of sub-queries
Write single-row and multiple-row sub-queries*/

use ankit
select * from customer;
-- 1 Single-Row Subquery:

-- Problem: Retrieve the highest payment amount.
SELECT MAX(amount) FROM payment;


-- 22. Single-Row Subquery with WHERE clause:
--- Problem: Retrieve the customer ID who made the highest payment.

SELECT customer_id
FROM payment
WHERE amount = (SELECT MAX(amount) FROM payment);

-- 33. Multiple-Row Subquery using IN:
 -- Problem: Retrieve customer IDs who made payments using 'Credit Card' or 'PayPal'.
SELECT DISTINCT customer_id
FROM payment
WHERE mode IN ('Credit Card', 'PayPal');

/*
4. Multiple-Row Subquery using EXISTS:
Problem: Retrieve customers who made at least one payment using 'Debit Card'
*/

SELECT DISTINCT customer_id
FROM payment p1
WHERE EXISTS (
    SELECT 1
    FROM payment p2
    WHERE p1.customer_id = p2.customer_id
      AND p2.mode = 'Debit Card'
);


-- 5. Single-Row Subquery with Aggregation:
-- Problem: Retrieve the total amount of all payments.

SELECT (SELECT SUM(amount) FROM payment) AS total_amount;

-- 6. Correlated Subquery with Aggregation:
-- Problem: Retrieve customers along with the total amount they've spent.
SELECT customer_id, 
       (SELECT SUM(amount) FROM payment p2 WHERE p1.customer_id = p2.customer_id) as total_amount
FROM payment p1
GROUP BY customer_id;


